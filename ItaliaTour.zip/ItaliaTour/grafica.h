#pragma once

#include "librerie.h"

void corniceAlto();
void corniceBasso();
void corniceMedio();
void car();
void menu();