#pragma once

#include "librerie.h"

#define CAR_SEPARATORE ';'
#define MAX_COL_CITTA 6

int leggiFile(paese &italia);
