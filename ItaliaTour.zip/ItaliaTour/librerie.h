#pragma once

#include <iostream>
#include <fstream>

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "grafica.h"
#include "record.h"
#include "letturaFile.h"
#include "funzioniGenerali.h"
#include "sqlite3.h"

using namespace std;
